package edu.cmu.sphinx.util.props;

/**
 * DOCUMENT ME!
 *
 * @author Holger Brandl
 */
public class AnotherDummyProcessor extends DummyProcessor {

}
