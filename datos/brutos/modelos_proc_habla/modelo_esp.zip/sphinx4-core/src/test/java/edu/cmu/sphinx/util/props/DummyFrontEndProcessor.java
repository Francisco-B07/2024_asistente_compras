package edu.cmu.sphinx.util.props;

import edu.cmu.sphinx.util.props.Configurable;

/**
 * DOCUMENT ME!
 *
 * @author Holger Brandl
 */
public interface DummyFrontEndProcessor extends Configurable {

}
